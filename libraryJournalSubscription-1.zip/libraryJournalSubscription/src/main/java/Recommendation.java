public class Recommendation {
}
